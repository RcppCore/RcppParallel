#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_MINUSONE_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_MINUSONE_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/minusone.hpp>
#include <boost/simd/arithmetic/functions/generic/minusone.hpp>

#endif
