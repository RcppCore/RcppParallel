#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_SUBS_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_SUBS_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/subs.hpp>
#include <boost/simd/arithmetic/functions/scalar/subs.hpp>

#endif
