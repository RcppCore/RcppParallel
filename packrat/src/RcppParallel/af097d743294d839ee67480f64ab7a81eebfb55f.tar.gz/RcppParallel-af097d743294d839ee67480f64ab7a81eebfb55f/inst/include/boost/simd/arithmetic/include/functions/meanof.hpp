#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_MEANOF_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_MEANOF_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/meanof.hpp>
#include <boost/simd/arithmetic/functions/generic/meanof.hpp>

#endif
