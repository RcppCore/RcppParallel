#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_FAST_TOINT_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_FAST_TOINT_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/fast_toint.hpp>
#include <boost/simd/arithmetic/functions/scalar/fast_toint.hpp>

#endif
