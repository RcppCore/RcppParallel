#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_REMQUO_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_REMQUO_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/remquo.hpp>
#include <boost/simd/arithmetic/functions/generic/remquo.hpp>

#endif
