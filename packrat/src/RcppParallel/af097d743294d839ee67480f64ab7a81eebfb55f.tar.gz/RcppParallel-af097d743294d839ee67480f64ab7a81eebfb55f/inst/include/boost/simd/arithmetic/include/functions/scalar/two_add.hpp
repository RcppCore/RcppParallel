#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_TWO_ADD_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_TWO_ADD_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/two_add.hpp>
#include <boost/simd/arithmetic/functions/generic/two_add.hpp>

#endif
