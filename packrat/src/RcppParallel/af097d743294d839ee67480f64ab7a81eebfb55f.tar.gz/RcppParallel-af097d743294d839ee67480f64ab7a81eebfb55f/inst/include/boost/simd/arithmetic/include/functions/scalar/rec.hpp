#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_REC_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_REC_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/rec.hpp>
#include <boost/simd/arithmetic/functions/scalar/rec.hpp>

#endif
