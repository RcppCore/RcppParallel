#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_IFLOOR_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_IFLOOR_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/ifloor.hpp>
#include <boost/simd/arithmetic/functions/generic/ifloor.hpp>

#endif
