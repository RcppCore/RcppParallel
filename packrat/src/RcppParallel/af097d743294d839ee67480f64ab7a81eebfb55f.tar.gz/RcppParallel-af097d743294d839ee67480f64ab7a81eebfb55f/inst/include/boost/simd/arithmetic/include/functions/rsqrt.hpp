#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_RSQRT_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_RSQRT_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/rsqrt.hpp>
#include <boost/simd/arithmetic/functions/generic/rsqrt.hpp>

#endif
