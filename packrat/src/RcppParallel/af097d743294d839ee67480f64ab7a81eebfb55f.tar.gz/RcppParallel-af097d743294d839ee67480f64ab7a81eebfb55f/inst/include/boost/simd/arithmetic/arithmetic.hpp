#ifndef BOOST_SIMD_ARITHMETIC_ARITHMETIC_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_ARITHMETIC_HPP_INCLUDED

#include <boost/simd/arithmetic/constants.hpp>
#include <boost/simd/arithmetic/functions.hpp>

#endif
