#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_REFINE_REC_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_REFINE_REC_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/refine_rec.hpp>
#include <boost/simd/arithmetic/functions/generic/refine_rec.hpp>

#endif
