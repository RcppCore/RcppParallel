#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_IDIVCEIL_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_IDIVCEIL_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/idivceil.hpp>
#include <boost/simd/arithmetic/functions/generic/idivceil.hpp>

#endif
