#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_DEC_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_DEC_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/dec.hpp>
#include <boost/simd/arithmetic/functions/generic/dec.hpp>

#endif
