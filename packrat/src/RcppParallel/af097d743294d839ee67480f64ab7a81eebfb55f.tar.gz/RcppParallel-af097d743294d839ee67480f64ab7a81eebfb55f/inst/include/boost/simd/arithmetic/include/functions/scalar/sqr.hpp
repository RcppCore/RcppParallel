#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_SQR_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_SQR_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/sqr.hpp>
#include <boost/simd/arithmetic/functions/generic/sqr.hpp>

#endif
