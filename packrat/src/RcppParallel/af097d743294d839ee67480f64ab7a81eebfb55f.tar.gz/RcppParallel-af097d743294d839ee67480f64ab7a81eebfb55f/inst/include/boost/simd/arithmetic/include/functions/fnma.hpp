#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_FNMA_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_FNMA_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/fnma.hpp>
#include <boost/simd/arithmetic/functions/generic/fnma.hpp>

#endif
