#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_FLOOR_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_FLOOR_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/floor.hpp>
#include <boost/simd/arithmetic/functions/generic/floor.hpp>
#include <boost/simd/arithmetic/functions/scalar/floor.hpp>

#endif
