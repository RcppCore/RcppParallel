#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_SQR_ABS_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_SQR_ABS_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/sqr_abs.hpp>
#include <boost/simd/arithmetic/functions/generic/sqr_abs.hpp>

#endif
