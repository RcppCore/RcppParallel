#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_ONEPLUS_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_ONEPLUS_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/oneplus.hpp>
#include <boost/simd/arithmetic/functions/generic/oneplus.hpp>

#endif
