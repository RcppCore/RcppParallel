#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_MIN_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_MIN_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/min.hpp>
#include <boost/simd/arithmetic/functions/scalar/min.hpp>

#endif
