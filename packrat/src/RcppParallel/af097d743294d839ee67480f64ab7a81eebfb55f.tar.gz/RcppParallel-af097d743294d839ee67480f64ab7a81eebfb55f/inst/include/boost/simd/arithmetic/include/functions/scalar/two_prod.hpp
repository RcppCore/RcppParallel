#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_TWO_PROD_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_TWO_PROD_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/two_prod.hpp>
#include <boost/simd/arithmetic/functions/generic/two_prod.hpp>

#endif
