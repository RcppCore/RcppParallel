#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_ICEIL_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_ICEIL_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/iceil.hpp>
#include <boost/simd/arithmetic/functions/generic/iceil.hpp>

#endif
