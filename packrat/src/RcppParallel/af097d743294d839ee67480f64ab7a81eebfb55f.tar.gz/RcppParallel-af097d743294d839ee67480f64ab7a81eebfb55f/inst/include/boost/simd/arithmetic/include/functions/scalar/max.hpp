#ifndef BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_MAX_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_INCLUDE_FUNCTIONS_SCALAR_MAX_HPP_INCLUDED

#include <boost/simd/arithmetic/functions/max.hpp>
#include <boost/simd/arithmetic/functions/scalar/max.hpp>

#endif
