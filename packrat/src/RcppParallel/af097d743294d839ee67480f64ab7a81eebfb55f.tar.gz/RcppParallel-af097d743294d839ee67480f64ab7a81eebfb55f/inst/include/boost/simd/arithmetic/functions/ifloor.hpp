//==============================================================================
//         Copyright 2003 - 2012   LASMEA UMR 6602 CNRS/Univ. Clermont II
//         Copyright 2009 - 2012   LRI    UMR 8623 CNRS/Univ Paris Sud XI
//
//          Distributed under the Boost Software License, Version 1.0.
//                 See accompanying file LICENSE.txt or copy at
//                     http://www.boost.org/LICENSE_1_0.txt
//==============================================================================
#ifndef BOOST_SIMD_ARITHMETIC_FUNCTIONS_IFLOOR_HPP_INCLUDED
#define BOOST_SIMD_ARITHMETIC_FUNCTIONS_IFLOOR_HPP_INCLUDED
#include <boost/simd/include/functor.hpp>
#include <boost/dispatch/include/functor.hpp>

namespace boost { namespace simd { namespace tag
  {
   /*!
      @brief  ifloor generic tag

      Represents the ifloor function in generic contexts.

      @par Models:
      Hierarchy
    **/
    struct ifloor_ : ext::elementwise_<ifloor_>
    {
      /// @brief Parent hierarchy
      typedef ext::elementwise_<ifloor_> parent;
      template<class... Args>
      static BOOST_FORCEINLINE BOOST_AUTO_DECLTYPE dispatch(Args&&... args)
      BOOST_AUTO_DECLTYPE_BODY( dispatching_ifloor_( ext::adl_helper(), static_cast<Args&&>(args)... ) )
    };
  }
  namespace ext
  {
   template<class Site, class... Ts>
   BOOST_FORCEINLINE generic_dispatcher<tag::ifloor_, Site> dispatching_ifloor_(adl_helper, boost::dispatch::meta::unknown_<Site>, boost::dispatch::meta::unknown_<Ts>...)
   {
     return generic_dispatcher<tag::ifloor_, Site>();
   }
   template<class... Args>
   struct impl_ifloor_;
  }
  /*!
    Computes the integer conversion of the floor of its parameter.

    @par semantic:
    For any given value @c x of type @c T:

    @code
    as_integer<T> r = ifloor(x);
    @endcode

    is equivalent to:

    @code
    as_integer<T> r = toints(floor(x));
    @endcode

    @par Note:
    This operation is properly saturated

    @see funcref{fast_ifloor}
    @param  a0

    @return an integral value of the integral type associated to the input.


  **/
  BOOST_DISPATCH_FUNCTION_IMPLEMENTATION(tag::ifloor_, ifloor, 1)
} }

#endif


